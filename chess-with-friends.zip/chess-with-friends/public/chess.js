// chess.js - Pure JavaScript Chess Engine
// No dependencies. Handles move generation, validation, check, checkmate, en passant, castling, promotion.

const PIECES = {
  wP: "wP", wN: "wN", wB: "wB", wR: "wR", wQ: "wQ", wK: "wK",
  bP: "bP", bN: "bN", bB: "bB", bR: "bR", bQ: "bQ", bK: "bK",
};

const FILES = ["a","b","c","d","e","f","g","h"];

function startPosition() {
  return {
    board: parseFEN("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"),
    turn: "w",
    castling: { wK: true, wQ: true, bK: true, bQ: true },
    enPassant: null,
    halfMove: 0,
    fullMove: 1,
  };
}

function parseFEN(fen) {
  const board = Array(8).fill(null).map(() => Array(8).fill(null));
  const [piecePart] = fen.split(" ");
  const rows = piecePart.split("/");
  for (let r = 0; r < 8; r++) {
    let c = 0;
    for (const ch of rows[r]) {
      if (ch >= "1" && ch <= "8") {
        c += parseInt(ch);
      } else {
        const color = ch === ch.toUpperCase() ? "w" : "b";
        board[r][c] = color + ch.toUpperCase();
        c++;
      }
    }
  }
  return board;
}

function boardToFEN(board, turn, castling, enPassant, halfMove, fullMove) {
  let fen = "";
  for (let r = 0; r < 8; r++) {
    let empty = 0;
    for (let c = 0; c < 8; c++) {
      if (!board[r][c]) {
        empty++;
      } else {
        if (empty) { fen += empty; empty = 0; }
        const piece = board[r][c];
        const letter = piece[1];
        fen += piece[0] === "w" ? letter.toUpperCase() : letter.toLowerCase();
      }
    }
    if (empty) fen += empty;
    if (r < 7) fen += "/";
  }
  const ep = enPassant ? `${FILES[enPassant.c]}${8 - enPassant.r}` : "-";
  const cast = [
    castling.wK ? "K" : "",
    castling.wQ ? "Q" : "",
    castling.bK ? "k" : "",
    castling.bQ ? "q" : "",
  ].join("") || "-";
  return `${fen} ${turn} ${cast} ${ep} ${halfMove} ${fullMove}`;
}

function cloneBoard(board) {
  return board.map(row => [...row]);
}

function cloneState(state) {
  return {
    board: cloneBoard(state.board),
    turn: state.turn,
    castling: { ...state.castling },
    enPassant: state.enPassant ? { ...state.enPassant } : null,
    halfMove: state.halfMove,
    fullMove: state.fullMove,
  };
}

function inBounds(r, c) {
  return r >= 0 && r < 8 && c >= 0 && c < 8;
}

function opponent(color) {
  return color === "w" ? "b" : "w";
}

// Raw moves (without check validation)
function rawMoves(state, r, c) {
  const { board, enPassant, castling } = state;
  const piece = board[r][c];
  if (!piece) return [];
  const color = piece[0];
  const type = piece[1];
  const moves = [];

  const slide = (dr, dc) => {
    let nr = r + dr, nc = c + dc;
    while (inBounds(nr, nc)) {
      if (board[nr][nc]) {
        if (board[nr][nc][0] !== color) moves.push([nr, nc]);
        break;
      }
      moves.push([nr, nc]);
      nr += dr; nc += dc;
    }
  };

  if (type === "P") {
    const dir = color === "w" ? -1 : 1;
    const startRow = color === "w" ? 6 : 1;
    if (inBounds(r + dir, c) && !board[r + dir][c]) {
      moves.push([r + dir, c]);
      if (r === startRow && !board[r + 2 * dir][c]) moves.push([r + 2 * dir, c]);
    }
    for (const dc of [-1, 1]) {
      if (inBounds(r + dir, c + dc)) {
        if (board[r + dir][c + dc]?.[0] === opponent(color)) moves.push([r + dir, c + dc]);
        if (enPassant && enPassant.r === r + dir && enPassant.c === c + dc) moves.push([r + dir, c + dc]);
      }
    }
  } else if (type === "N") {
    for (const [dr, dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
      const nr = r+dr, nc = c+dc;
      if (inBounds(nr,nc) && board[nr][nc]?.[0] !== color) moves.push([nr,nc]);
    }
  } else if (type === "B") {
    for (const [dr,dc] of [[-1,-1],[-1,1],[1,-1],[1,1]]) slide(dr,dc);
  } else if (type === "R") {
    for (const [dr,dc] of [[-1,0],[1,0],[0,-1],[0,1]]) slide(dr,dc);
  } else if (type === "Q") {
    for (const [dr,dc] of [[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]]) slide(dr,dc);
  } else if (type === "K") {
    for (const [dr,dc] of [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]]) {
      const nr=r+dr, nc=c+dc;
      if (inBounds(nr,nc) && board[nr][nc]?.[0] !== color) moves.push([nr,nc]);
    }
    // Castling
    const row = color === "w" ? 7 : 0;
    if (r === row && c === 4) {
      if (castling[color + "K"] && !board[row][5] && !board[row][6] &&
          board[row][7] === color + "R" &&
          !isSquareAttacked(state, row, 4, opponent(color)) &&
          !isSquareAttacked(state, row, 5, opponent(color)) &&
          !isSquareAttacked(state, row, 6, opponent(color))) {
        moves.push([row, 6]);
      }
      if (castling[color + "Q"] && !board[row][3] && !board[row][2] && !board[row][1] &&
          board[row][0] === color + "R" &&
          !isSquareAttacked(state, row, 4, opponent(color)) &&
          !isSquareAttacked(state, row, 3, opponent(color)) &&
          !isSquareAttacked(state, row, 2, opponent(color))) {
        moves.push([row, 2]);
      }
    }
  }
  return moves;
}

function isSquareAttacked(state, r, c, byColor) {
  for (let fr = 0; fr < 8; fr++) {
    for (let fc = 0; fc < 8; fc++) {
      if (state.board[fr][fc]?.[0] === byColor) {
        const moves = rawMoves({ ...state, turn: byColor }, fr, fc);
        if (moves.some(([mr, mc]) => mr === r && mc === c)) return true;
      }
    }
  }
  return false;
}

function findKing(board, color) {
  for (let r = 0; r < 8; r++)
    for (let c = 0; c < 8; c++)
      if (board[r][c] === color + "K") return [r, c];
  return null;
}

function inCheck(state, color) {
  const [kr, kc] = findKing(state.board, color);
  return isSquareAttacked(state, kr, kc, opponent(color));
}

function applyMove(state, fr, fc, tr, tc, promotion = "Q") {
  const next = cloneState(state);
  const board = next.board;
  const piece = board[fr][fc];
  const color = piece[0];
  const type = piece[1];

  next.enPassant = null;

  // En passant capture
  if (type === "P" && state.enPassant && tr === state.enPassant.r && tc === state.enPassant.c) {
    board[fr][tc] = null;
  }

  // Pawn double push
  if (type === "P" && Math.abs(tr - fr) === 2) {
    next.enPassant = { r: (fr + tr) / 2, c: fc };
  }

  // Castling rook move
  if (type === "K") {
    const row = color === "w" ? 7 : 0;
    if (fc === 4 && tc === 6) { board[row][5] = color + "R"; board[row][7] = null; }
    if (fc === 4 && tc === 2) { board[row][3] = color + "R"; board[row][0] = null; }
    next.castling[color + "K"] = false;
    next.castling[color + "Q"] = false;
  }

  if (type === "R") {
    if (fc === 0) next.castling[color + "Q"] = false;
    if (fc === 7) next.castling[color + "K"] = false;
  }

  board[tr][tc] = piece;
  board[fr][fc] = null;

  // Promotion
  if (type === "P" && (tr === 0 || tr === 7)) {
    board[tr][tc] = color + promotion;
  }

  next.turn = opponent(color);
  next.halfMove = (type === "P" || state.board[tr][tc]) ? 0 : state.halfMove + 1;
  if (color === "b") next.fullMove++;

  return next;
}

function legalMoves(state, r, c) {
  const piece = state.board[r][c];
  if (!piece || piece[0] !== state.turn) return [];
  const color = piece[0];
  return rawMoves(state, r, c).filter(([tr, tc]) => {
    const next = applyMove(state, r, c, tr, tc);
    return !inCheck(next, color);
  });
}

function allLegalMoves(state) {
  const moves = [];
  for (let r = 0; r < 8; r++)
    for (let c = 0; c < 8; c++)
      if (state.board[r][c]?.[0] === state.turn)
        for (const [tr, tc] of legalMoves(state, r, c))
          moves.push([r, c, tr, tc]);
  return moves;
}

function isCheckmate(state) {
  return inCheck(state, state.turn) && allLegalMoves(state).length === 0;
}

function isStalemate(state) {
  return !inCheck(state, state.turn) && allLegalMoves(state).length === 0;
}

function toAlgebraic(r, c) {
  return FILES[c] + (8 - r);
}

module.exports = {
  startPosition, parseFEN, boardToFEN, cloneState,
  legalMoves, allLegalMoves, applyMove, inCheck, isCheckmate, isStalemate,
  toAlgebraic, findKing,
};
