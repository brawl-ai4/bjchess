# ♟ Chess With Friends

Real-time multiplayer chess over WebSockets. No accounts, no installation for players — just share a room code and play.

## Features

- 🏠 **Room-based matchmaking** — Create a room, share the code, your friend joins
- ♟ **Full chess rules** — En passant, castling, pawn promotion, check/checkmate/stalemate, 50-move rule
- ⏱ **10-minute timers** — Both sides get 10 minutes, clock switches on each move
- 💬 **In-game chat** — Talk trash or be sportsmanlike
- 🔄 **Rematch** — Colors swap automatically on rematch
- 🏳️ **Resign / Draw offer** — Full game controls
- 📱 **Mobile-friendly** — Responsive layout for phones and tablets

## Quick Start

### Prerequisites
- [Node.js](https://nodejs.org/) v18 or higher

### Setup

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/chess-with-friends.git
cd chess-with-friends

# Install dependencies
npm install

# Start the server
npm start
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Development (auto-reload)

```bash
npm run dev
```

## How to Play

1. **Player 1:** Click **Create Room** → gets a 6-character room code
2. **Player 2:** Enter the room code and click **Join Room**
3. White moves first — click a piece, then click the destination square
4. Legal moves are highlighted — dots for empty squares, rings for captures
5. The game ends on checkmate, stalemate, timeout, resignation, or agreed draw

## Project Structure

```
chess-with-friends/
├── public/
│   ├── index.html    # Frontend (HTML/CSS/JS, no framework)
│   └── chess.js      # Pure JS chess engine (moves, check, mate)
├── src/
│   └── server.js     # Express + WebSocket server, room management
├── package.json
└── README.md
```

## Deployment

### Railway / Render / Fly.io

These platforms detect Node.js apps automatically. Set the start command to `npm start` and deploy.

### Heroku

```bash
heroku create
git push heroku main
```

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT`   | `3000`  | Server port |

## Tech Stack

- **Backend:** Node.js, Express, `ws` (WebSocket library)
- **Frontend:** Vanilla HTML/CSS/JavaScript — zero dependencies
- **Chess logic:** Custom engine in `public/chess.js`
- **Fonts:** Playfair Display + DM Mono (Google Fonts)

## License

MIT — do whatever you want with it.
