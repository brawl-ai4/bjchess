const express = require("express");
const { WebSocketServer } = require("ws");
const { createServer } = require("http");
const { v4: uuidv4 } = require("uuid");
const path = require("path");

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.static(path.join(__dirname, "../public")));

// rooms: { roomId -> { white: ws, black: ws, fen: string, moves: [], chat: [] } }
const rooms = new Map();

function broadcast(room, data, exclude = null) {
  const msg = JSON.stringify(data);
  for (const color of ["white", "black"]) {
    const client = room[color];
    if (client && client !== exclude && client.readyState === 1) {
      client.send(msg);
    }
  }
}

function send(ws, data) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(data));
}

wss.on("connection", (ws) => {
  ws.roomId = null;
  ws.color = null;

  ws.on("message", (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }

    if (msg.type === "create_room") {
      const roomId = Math.random().toString(36).substring(2, 8).toUpperCase();
      rooms.set(roomId, {
        white: ws,
        black: null,
        fen: "start",
        moves: [],
        chat: [],
        whiteTime: 600,
        blackTime: 600,
        timerActive: false,
        turn: "white",
        timerInterval: null,
      });
      ws.roomId = roomId;
      ws.color = "white";
      send(ws, { type: "room_created", roomId, color: "white" });
    }

    else if (msg.type === "join_room") {
      const roomId = msg.roomId?.toUpperCase();
      if (!rooms.has(roomId)) {
        send(ws, { type: "error", message: "Room not found." });
        return;
      }
      const room = rooms.get(roomId);
      if (room.black) {
        send(ws, { type: "error", message: "Room is full." });
        return;
      }
      room.black = ws;
      ws.roomId = roomId;
      ws.color = "black";
      send(ws, { type: "room_joined", roomId, color: "black", fen: room.fen, moves: room.moves });
      broadcast(room, { type: "opponent_joined", color: "black" }, ws);
      broadcast(room, { type: "game_start", whiteTime: room.whiteTime, blackTime: room.blackTime });

      // Start timer
      room.timerActive = true;
      room.timerInterval = setInterval(() => {
        if (!room.timerActive) return;
        if (room.turn === "white") room.whiteTime--;
        else room.blackTime--;

        broadcast(room, { type: "timer_update", whiteTime: room.whiteTime, blackTime: room.blackTime });

        if (room.whiteTime <= 0 || room.blackTime <= 0) {
          clearInterval(room.timerInterval);
          room.timerActive = false;
          const winner = room.whiteTime <= 0 ? "black" : "white";
          broadcast(room, { type: "game_over", reason: "timeout", winner });
        }
      }, 1000);
    }

    else if (msg.type === "move") {
      const room = rooms.get(ws.roomId);
      if (!room) return;
      room.fen = msg.fen;
      room.moves.push(msg.move);
      room.turn = room.turn === "white" ? "black" : "white";
      broadcast(room, { type: "move", move: msg.move, fen: msg.fen, turn: room.turn }, ws);

      if (msg.gameOver) {
        if (room.timerInterval) clearInterval(room.timerInterval);
        room.timerActive = false;
        broadcast(room, { type: "game_over", reason: msg.reason, winner: msg.winner }, ws);
      }
    }

    else if (msg.type === "chat") {
      const room = rooms.get(ws.roomId);
      if (!room) return;
      const entry = { color: ws.color, text: msg.text, time: Date.now() };
      room.chat.push(entry);
      broadcast(room, { type: "chat", ...entry });
    }

    else if (msg.type === "resign") {
      const room = rooms.get(ws.roomId);
      if (!room) return;
      if (room.timerInterval) clearInterval(room.timerInterval);
      room.timerActive = false;
      const winner = ws.color === "white" ? "black" : "white";
      broadcast(room, { type: "game_over", reason: "resign", winner });
    }

    else if (msg.type === "draw_offer") {
      const room = rooms.get(ws.roomId);
      if (!room) return;
      broadcast(room, { type: "draw_offer", from: ws.color }, ws);
    }

    else if (msg.type === "draw_accept") {
      const room = rooms.get(ws.roomId);
      if (!room) return;
      if (room.timerInterval) clearInterval(room.timerInterval);
      room.timerActive = false;
      broadcast(room, { type: "game_over", reason: "draw", winner: null });
    }

    else if (msg.type === "rematch") {
      const room = rooms.get(ws.roomId);
      if (!room) return;
      room.rematchVotes = (room.rematchVotes || 0) + 1;
      if (room.rematchVotes >= 2) {
        room.rematchVotes = 0;
        room.fen = "start";
        room.moves = [];
        room.whiteTime = 600;
        room.blackTime = 600;
        room.turn = "white";
        room.timerActive = true;
        if (room.timerInterval) clearInterval(room.timerInterval);
        // Swap colors
        const tmp = room.white;
        room.white = room.black;
        room.black = tmp;
        if (room.white) room.white.color = "white";
        if (room.black) room.black.color = "black";

        send(room.white, { type: "rematch_start", color: "white", whiteTime: 600, blackTime: 600 });
        send(room.black, { type: "rematch_start", color: "black", whiteTime: 600, blackTime: 600 });

        room.timerInterval = setInterval(() => {
          if (!room.timerActive) return;
          if (room.turn === "white") room.whiteTime--;
          else room.blackTime--;
          broadcast(room, { type: "timer_update", whiteTime: room.whiteTime, blackTime: room.blackTime });
          if (room.whiteTime <= 0 || room.blackTime <= 0) {
            clearInterval(room.timerInterval);
            room.timerActive = false;
            const winner = room.whiteTime <= 0 ? "black" : "white";
            broadcast(room, { type: "game_over", reason: "timeout", winner });
          }
        }, 1000);
      } else {
        broadcast(room, { type: "rematch_requested", from: ws.color }, ws);
      }
    }
  });

  ws.on("close", () => {
    if (!ws.roomId) return;
    const room = rooms.get(ws.roomId);
    if (!room) return;
    if (room.timerInterval) clearInterval(room.timerInterval);
    room.timerActive = false;
    broadcast(room, { type: "opponent_disconnected" }, ws);
    rooms.delete(ws.roomId);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`♟  Chess server running at http://localhost:${PORT}`);
});
